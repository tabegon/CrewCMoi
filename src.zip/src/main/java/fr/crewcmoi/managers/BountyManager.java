package fr.crewcmoi.managers;

import fr.crewcmoi.Main;
import fr.crewcmoi.database.BountyEntry;
import fr.crewcmoi.database.BountyTarget;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Gère la logique des primes (bounty) :
 * - ajout d'une prime par un joueur sur un autre (/bounty add)
 * - réclamation de la prime en tuant la cible
 * - attribution automatique d'une prime + malus par le serveur en cas d'agression injustifiée
 */
public class BountyManager {

    private final Main plugin;
    private final DatabaseManager databaseManager;
    private final EconomyManager economyManager;
    private final MalusEffectManager malusEffectManager;

    // Nom de l'objectif de scoreboard utilisé pour afficher la prime d'un joueur
    // sous son nom (BELOW_NAME), au-dessus de sa barre de vie.
    private static final String OBJECTIVE_NAME = "crew_bounty";

    public BountyManager(Main plugin, DatabaseManager databaseManager, EconomyManager economyManager,
                          MalusEffectManager malusEffectManager) {
        this.plugin = plugin;
        this.databaseManager = databaseManager;
        this.economyManager = economyManager;
        this.malusEffectManager = malusEffectManager;
    }

    public enum AddResult {
        SUCCESS, INVALID_AMOUNT, SELF_TARGET, NOT_ENOUGH_MONEY, TARGET_NOT_FOUND
    }

    /**
     * Ajoute une prime placée par un joueur sur un autre : l'argent est immédiatement débité.
     */
    public void addPlayerBounty(Player sender, String targetName, double amount, String reason, Consumer<AddResult> callback) {
        if (!Double.isFinite(amount) || amount <= 0) {
            callback.accept(AddResult.INVALID_AMOUNT);
            return;
        }

        var targetData = economyManager.getPlayerDataByName(targetName);
        if (targetData == null) {
            callback.accept(AddResult.TARGET_NOT_FOUND);
            return;
        }

        if (targetData.getUuid().equals(sender.getUniqueId())) {
            callback.accept(AddResult.SELF_TARGET);
            return;
        }

        if (!economyManager.withdraw(sender.getUniqueId(), amount)) {
            callback.accept(AddResult.NOT_ENOUGH_MONEY);
            return;
        }

        addBountyAndRefresh(targetData.getUuid(), targetData.getName(), sender.getUniqueId(), sender.getName(), amount, reason);
        callback.accept(AddResult.SUCCESS);
    }

    /**
     * Ajoute une prime attribuée automatiquement par le serveur (contributeur = null).
     */
    public void addServerBounty(UUID targetUuid, String targetName, double amount) {
        addBountyAndRefresh(targetUuid, targetName, null, "Serveur", amount, null);
    }

    /**
     * Insère la contribution de prime PUIS recalcule l'affichage/les effets de malus, dans
     * la même tâche asynchrone (donc dans l'ordre garanti). L'ancienne version lançait ces
     * deux étapes comme deux tâches asynchrones séparées : comme le scheduler asynchrone de
     * Bukkit peut les exécuter sur des threads différents sans garantir l'ordre, la lecture
     * du total pouvait s'exécuter AVANT l'écriture de la nouvelle prime, et donc rater le
     * changement (le malus ne s'appliquait alors qu'au prochain recalcul, ex: le kill suivant).
     */
    private void addBountyAndRefresh(UUID targetUuid, String targetName, UUID contributorUuid,
                                      String contributorName, double amount, String reason) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            databaseManager.addBounty(targetUuid, targetName, contributorUuid, contributorName, amount, reason);

            List<BountyEntry> entries = databaseManager.getBounties(targetUuid);
            double total = entries.stream().mapToDouble(BountyEntry::getAmount).sum();
            double serverTotal = entries.stream()
                    .filter(BountyEntry::isServerBounty)
                    .mapToDouble(BountyEntry::getAmount)
                    .sum();

            Bukkit.getScheduler().runTask(plugin, () -> {
                applyBountyDisplay(targetName, total);
                Player player = Bukkit.getPlayer(targetUuid);
                if (player != null && player.isOnline()) {
                    malusEffectManager.updateBountyEffect(player, serverTotal);
                }
            });
        });
    }

    public int getServerBountyCountToday(UUID playerUuid) {
        return databaseManager.getServerBountyCountToday(playerUuid);
    }

    public void incrementServerBountyCount(UUID playerUuid) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> databaseManager.incrementServerBountyCount(playerUuid));
    }

    public List<BountyEntry> getBounties(UUID targetUuid) {
        return databaseManager.getBounties(targetUuid);
    }

    public List<BountyTarget> getBountyTargets() {
        return databaseManager.getBountyTargets();
    }

    /**
     * Résultat d'une réclamation de prime après un kill (voir claimBounty) : le montant
     * effectivement versé au killer, et si cette prime était "légitime" (auquel cas le kill
     * n'est PAS traité comme un kill sans prime valide : pas de malus/mise à prix du killer,
     * voir BountyListener).
     */
    public record BountyClaimResult(double amount, boolean legitimate) {
    }

    /**
     * Tente de faire réclamer par le killer la prime placée sur la victime.
     * Ne s'applique QUE lors d'une mort causée par un autre joueur (voir BountyListener).
     * Le killer touche TOUJOURS l'intégralité de la prime de la victime (y compris les
     * contributions placées par lui-même/ses alliés, ou avec une raison jamais approuvée) :
     * il "récupère la prime qu'avait le joueur sur sa tête" dans tous les cas.
     * Ce qui change, c'est la légitimité retournée, qui détermine si BountyListener applique
     * le malus serveur (mise à prix du killer) :
     *  - légitime (true) si AU MOINS une contribution valide existe : une prime serveur, ou
     *    une prime posée par un joueur qui n'est ni le killer ni un de ses alliés d'équipe
     *    (voir excludedContributor), et qui est soit sans raison, soit approuvée par un admin
     *    (/bounty review) — pas de malus dans ce cas.
     *  - non légitime (false) si la victime n'avait aucune prime, ou si TOUTES ses
     *    contributions viennent du killer/ses alliés, ou ont une raison jamais approuvée :
     *    le kill est alors traité comme un kill sans prime valide (malus + mise à prix du
     *    killer, voir BountyListener), même si de l'argent a quand même été versé au killer.
     * Dans tous les cas, la totalité des contributions de la victime est effacée par ce
     * kill, ce qui lève au passage l'effet de malchance associé.
     *
     * En cas de mort d'une autre nature (cause naturelle, suicide, etc.), cette méthode
     * n'est jamais appelée : la prime (et donc l'effet de malchance) reste intacte.
     *
     * @param excludedContributor prédicat renvoyant vrai pour un contributeur (le killer
     *                             lui-même ou l'un de ses alliés) dont la contribution ne
     *                             doit pas compter comme une prime "légitime".
     */
    public BountyClaimResult claimBounty(UUID killerUuid, UUID victimUuid, Predicate<UUID> excludedContributor) {
        List<BountyEntry> entries = databaseManager.getBounties(victimUuid);
        if (entries.isEmpty()) {
            return new BountyClaimResult(0.0, false);
        }

        double total = 0.0;
        boolean legitimate = false;
        for (BountyEntry entry : entries) {
            total += entry.getAmount();

            boolean excluded = !entry.isServerBounty() && excludedContributor.test(entry.getContributorUuid());
            boolean valid = entry.isServerBounty() || (!excluded && (!entry.hasReason() || entry.isApproved()));
            if (valid) {
                legitimate = true;
            }
        }

        // On efface systématiquement TOUTES les contributions : elles ne peuvent plus être
        // "récupérées" ni révisées plus tard, que la prime ait été jugée légitime ou non.
        databaseManager.clearBounties(victimUuid);

        if (total > 0) {
            economyManager.deposit(killerUuid, total);
        }

        Player victim = Bukkit.getPlayer(victimUuid);
        if (victim != null) {
            clearBountyDisplay(victim.getName());
            // Toute la prime (y compris la part serveur) vient d'être effacée par ce kill :
            // l'effet de malchance associé est donc levé immédiatement.
            malusEffectManager.updateBountyEffect(victim, 0.0);
        }

        return new BountyClaimResult(total, legitimate);
    }

    /**
     * Retourne les contributions de prime avec une raison fournie par un joueur, en attente
     * de validation par un admin (voir /bounty review).
     */
    public List<BountyEntry> getPendingReasonedBounties() {
        return databaseManager.getPendingReasonedBounties();
    }

    /**
     * Approuve une raison de prime : elle devient valide pour un futur kill (le tueur pourra
     * la réclamer, et le kill ne déclenchera pas le malus serveur).
     */
    public void approveBounty(int entryId, Consumer<Boolean> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            BountyEntry entry = databaseManager.getBountyEntry(entryId);
            if (entry == null) {
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(false));
                return;
            }
            databaseManager.setBountyApproved(entryId, true);
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(true));
        });
    }

    /**
     * Refuse une raison de prime : la contribution est supprimée et son montant remboursé
     * au contributeur.
     */
    public void denyBounty(int entryId, Consumer<Boolean> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            BountyEntry entry = databaseManager.getBountyEntry(entryId);
            if (entry == null) {
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(false));
                return;
            }
            databaseManager.deleteBountyEntry(entryId);
            if (!entry.isServerBounty()) {
                economyManager.deposit(entry.getContributorUuid(), entry.getAmount());
            }

            List<BountyEntry> remaining = databaseManager.getBounties(entry.getTargetUuid());
            double total = remaining.stream().mapToDouble(BountyEntry::getAmount).sum();
            double serverTotal = remaining.stream()
                    .filter(BountyEntry::isServerBounty)
                    .mapToDouble(BountyEntry::getAmount)
                    .sum();

            Bukkit.getScheduler().runTask(plugin, () -> {
                applyBountyDisplay(entry.getTargetName(), total);
                Player target = Bukkit.getPlayer(entry.getTargetUuid());
                if (target != null && target.isOnline()) {
                    malusEffectManager.updateBountyEffect(target, serverTotal);
                }
                callback.accept(true);
            });
        });
    }

    /**
     * Recalcule (de façon asynchrone) le total des primes actives d'un joueur et met à jour
     * son affichage visuel (pseudo rouge + prime en gold) en conséquence, ainsi que ses
     * effets de malus de prime serveur (réduction de dégâts + coeurs retirés), qui ne
     * dépendent eux que de la part de la prime attribuée par le serveur.
     */
    public void refreshBountyDisplay(UUID uuid, String name) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<BountyEntry> entries = databaseManager.getBounties(uuid);
            double total = entries.stream().mapToDouble(BountyEntry::getAmount).sum();
            double serverTotal = entries.stream()
                    .filter(BountyEntry::isServerBounty)
                    .mapToDouble(BountyEntry::getAmount)
                    .sum();
            Bukkit.getScheduler().runTask(plugin, () -> {
                applyBountyDisplay(name, total);
                Player player = Bukkit.getPlayer(uuid);
                if (player != null && player.isOnline()) {
                    malusEffectManager.updateBountyEffect(player, serverTotal);
                }
            });
        });
    }

    /**
     * Réapplique l'affichage de prime d'un joueur qui vient de se connecter (synchrone, à
     * appeler depuis le thread principal au join).
     */
    public void refreshBountyDisplayOnJoin(UUID uuid, String name) {
        refreshBountyDisplay(uuid, name);
    }

    /**
     * Affiche (ou met à jour) la prime du joueur sous son nom (BELOW_NAME), via un score
     * de scoreboard. La prime n'est donc plus visible au-dessus de la tête (nametag) ni
     * dans le tab : uniquement sous le nom du joueur, au-dessus de sa barre de vie.
     */
    private void applyBountyDisplay(String playerName, double total) {
        if (total > 0) {
            Objective objective = getBountyObjective();
            objective.getScore(playerName).setScore((int) Math.round(total));
        } else {
            clearBountyDisplay(playerName);
        }
    }

    private void clearBountyDisplay(String playerName) {
        Scoreboard board = getMainScoreboard();
        if (board.getObjective(OBJECTIVE_NAME) != null) {
            board.resetScores(playerName);
        }
    }

    /**
     * Récupère (ou crée si besoin) l'objectif de scoreboard "prime", affiché sous le nom
     * de chaque joueur concerné (BELOW_NAME).
     */
    private Objective getBountyObjective() {
        Scoreboard board = getMainScoreboard();
        Objective objective = board.getObjective(OBJECTIVE_NAME);
        if (objective == null) {
            String currency = plugin.getConfig().getString("economy.currency-symbol", "§f");
            objective = board.registerNewObjective(OBJECTIVE_NAME, "dummy", ChatColor.GOLD + currency);
            objective.setDisplaySlot(DisplaySlot.BELOW_NAME);
        }
        return objective;
    }

    private Scoreboard getMainScoreboard() {
        return Bukkit.getScoreboardManager().getMainScoreboard();
    }
}
